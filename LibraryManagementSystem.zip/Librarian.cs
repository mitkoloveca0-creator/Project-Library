
public class Librarian : User
{
    public Librarian(string name, int id) : base(name, id) { }

    public void AddBook(Library library, string title)
    {
        library.AddBook(title);
    }

    public override void BorrowBook(Library library, string bookTitle) { }
    public override void ReturnBook(Library library, string bookTitle) { }
}
