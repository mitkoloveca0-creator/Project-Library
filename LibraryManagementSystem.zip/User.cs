
public abstract class User
{
    protected string name;
    protected int id;

    protected User(string name, int id)
    {
        this.name = name;
        this.id = id;
    }

    public abstract void BorrowBook(Library library, string bookTitle);
    public abstract void ReturnBook(Library library, string bookTitle);
}
