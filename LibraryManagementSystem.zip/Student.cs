
using System.Collections.Generic;

public class Student : User
{
    private List<string> borrowedBooks = new List<string>();

    public Student(string name, int id) : base(name, id) { }

    public override void BorrowBook(Library library, string bookTitle)
    {
        library.BorrowBook(bookTitle);
        borrowedBooks.Add(bookTitle);
    }

    public override void ReturnBook(Library library, string bookTitle)
    {
        if (!borrowedBooks.Contains(bookTitle))
            throw new BookNotBorrowedException("Книгата не е заета от този студент.");

        library.ReturnBook(bookTitle);
        borrowedBooks.Remove(bookTitle);
    }
}
