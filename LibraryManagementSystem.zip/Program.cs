
using System;

class Program
{
    static void Main()
    {
        Library library = new Library();
        Librarian librarian = new Librarian("Мария", 1);
        Student student = new Student("Иван", 101);

        librarian.AddBook(library, "1984");
        librarian.AddBook(library, "Под игото");
        librarian.AddBook(library, "Престъпление и наказание");

        library.ShowAvailableBooks();

        try
        {
            student.BorrowBook(library, "1984");
            library.ShowAvailableBooks();

            student.ReturnBook(library, "1984");
            library.ShowAvailableBooks();

            student.ReturnBook(library, "Под игото");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Грешка: " + ex.Message);
        }
    }
}
