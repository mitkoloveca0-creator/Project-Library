
using System;
using System.Collections.Generic;

public class Library
{
    private Dictionary<string, bool> books = new Dictionary<string, bool>();

    public void AddBook(string title)
    {
        books[title] = true;
    }

    public void BorrowBook(string title)
    {
        if (!books.ContainsKey(title) || !books[title])
            throw new BookNotAvailableException("Книгата не е налична.");

        books[title] = false;
    }

    public void ReturnBook(string title)
    {
        if (!books.ContainsKey(title) || books[title])
            throw new BookNotBorrowedException("Книгата не е била заета.");

        books[title] = true;
    }

    public void ShowAvailableBooks()
    {
        Console.WriteLine("Налични книги:");
        foreach (var book in books)
            if (book.Value) Console.WriteLine("- " + book.Key);
    }
}
